//
//  ContentView.swift
//  Purpaws
//
//  Created by STUDENT on 10/18/24.
//

import SwiftUI
import Firebase

struct ContentView: View {
    var body: some View {
        NavigationView {
            
            FirstScreen()
        }
    }
}

#Preview {
    ContentView()
}
